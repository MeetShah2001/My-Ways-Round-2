import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Form from "./components/Form";
import Foods from "./components/Foods";
import Navigation from "./components/Navigation";

function App() {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route path="/" element={<Form />} />
        <Route path="/foods" element={<Foods />} />
        <Route path="/foods" element={<Navigation />} />
      </Routes>
    </Router>
  );
}

export default App;
