import React, { useState } from "react";

const Form = () => {
  const [foodName, setFoodName] = useState("");
  const [foodType, setFoodType] = useState("Delicious Food");
  const [maxDeliveryTime, setMaxDeliveryTime] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    const food = {
      foodName,
      foodType,
      maxDeliveryTime,
    };
    localStorage.setItem("food", JSON.stringify(food));
    setFoodName("");
    setFoodType("Delicious Food");
    setMaxDeliveryTime("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Food Name: 
        <input
          type="text"
          value={foodName}
          onChange={(event) => setFoodName(event.target.value)}
        />
      </label>
      <br />
      <label>
        Food Type: 
        <select
          value={foodType}
          onChange={(event) => setFoodType(event.target.value)}
        >
          <option value="Delicious Food">Delicious Food</option>
          <option value="Nutritious Food">Nutritious Food</option>
          <option value="Fast Food">Fast Food</option>
          <option value="Beverages">Beverages</option>
          <option value="Desserts">Desserts</option>
        </select>
      </label>
      <br />
      <label>
        Max Delivery Time (in minutes): 
        <input
          type="number"
          value={maxDeliveryTime}
          onChange={(event) => setMaxDeliveryTime(event.target.value)}
        />
      </label>
      <br />
      <button type="submit">Submit</button>
    </form>
  );
};

export default Form;
